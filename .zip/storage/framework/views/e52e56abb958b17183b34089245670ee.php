

<?php $__env->startSection('content'); ?>

    
    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Testimonials</strong>
                        </div>
                        <div class="table-stats order-table ov-h">
                            <table class="table ">
                                <thead>
                                    <tr>
                                        <th class="serial">#</th>
                                        <th>Name</th>
                                        <th>Designation</th>
                                        <th>Message</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="serial"><?php echo e($loop->iteration); ?>.</td>
                                            <td> <span class="name"><?php echo e($testimonial->name); ?></span> </td>
                                            <td> <span class="designation"><?php echo e($testimonial->designation); ?></span> </td  >
                                            <td> <span class="message"><?php echo e(Str::limit($testimonial->message, 50)); ?></span> </td>
                                            <td>
                                                <div class="btn-group btn-group-sm ">
                                                    <a href="<?php echo e(route('testimonials.edit', $testimonial->id)); ?>" style="font-size:2rem; color:#007bff; display:inline-block; margin-right:10px;"><i class="fa fa-edit"></i></a>
                                                    <form action="<?php echo e(route('testimonials.destroy', $testimonial->id)); ?>" method="POST" style="display:inline-block;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" style="font-size:2rem; color:#bd2601; background:none; border:none; cursor:pointer;"><i class="fa fa-trash"></i></button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div> <!-- /.table-stats -->
                    </div>
                </div>
            </div>
        </div>
    </div>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\najam\resources\views/testimonials/index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Blogs</strong>
                        </div>
                        <div class="card-body card-block">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Title</th>
                                        <th>Slug</th>
                                        <th>description</th>
                                        <th>Author</th>
                                        <th>Published At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php if($blog->image): ?>
                                                    <img src="<?php echo e(asset('storage/' . $blog->image)); ?>" alt="Blog Image" style="width: 50px; height: 50px;">
                                                <?php else: ?>
                                                    No Image
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($blog->title); ?></td>
                                            <td><?php echo e($blog->slug); ?></td>
                                            <td><?php echo e(Str::limit($blog->content, 100)); ?></td>
                                            <td><?php echo e($blog->author); ?></td>
                                            <td>
                                                <?php if($blog->published_at): ?>
                                                    <?php
                                                        $publishedAt = \Carbon\Carbon::parse($blog->published_at);
                                                    ?>
                                                    <?php echo e($publishedAt->format('d M Y h:i A')); ?>

                                                <?php else: ?>
                                                    Draft
                                                <?php endif; ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('blog.edit', $blog->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                                                <button class="btn btn-sm btn-danger delete-blog" data-id="<?php echo e($blog->id); ?>">Delete</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <?php echo e($blogs->links()); ?> <!-- Pagination links -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.querySelectorAll('.delete-blog').forEach(function(btn) {
    btn.addEventListener('click', function() {
        if (!confirm('Are you sure you want to delete this blog?')) return;
        const id = this.getAttribute('data-id');
        fetch('<?php echo e(url("/blog")); ?>/' + id, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                'Accept': 'application/json'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message || 'Delete failed');
            }
        });
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\najam\resources\views/resources/index.blade.php ENDPATH**/ ?>
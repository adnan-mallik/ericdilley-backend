<header id="header" class="header">
    <div class="top-left">
        <div class="navbar-header">
            <a class="navbar-brand" href="./">
                
                <span style="font-wight:bolder"><strong>BE</strong></span>
                <span style="font-wight:bolder; color:rgba(241, 207, 11, 0.959)"><strong>ADDICTED</strong></span>
            </a>
            <a class="navbar-brand hidden" href="./"><img src="<?php echo e(asset('images/logo2.png')); ?>" alt="Logo"></a>
            <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
        </div>
    </div>
    <div class="top-right">
        <div class="header-menu">
            

            <div class="user-area dropdown float-right">
                <a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img class="user-avatar rounded-circle" src="<?php echo e(asset('images/logo.png')); ?>" alt="User Avatar">
                </a>

                <div class="user-menu dropdown-menu">
                    

                    <a  class="nav-link" 
                        href="<?php echo e(route('logout')); ?>" 
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();" 
                    >
                        <i class="fa fa-power -off"></i><?php echo e(__('Logout')); ?>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </a>
                                    
                </div>
            </div>

        </div>
    </div>
</header><?php /**PATH C:\laragon\www\najam\resources\views/includes/topbar.blade.php ENDPATH**/ ?>
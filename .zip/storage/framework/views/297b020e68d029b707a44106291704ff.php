

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <strong>Podcasts List</strong>
                        <a href="<?php echo e(route('podcasts.create')); ?>" class="btn btn-primary btn-sm float-right">Add Podcast</a>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Slug</th>
                                    <th>Video URL</th>
                                    <th>Published At</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $podcasts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $podcast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($podcast->title); ?></td>
                                    <td><?php echo e($podcast->slug); ?></td>
                                    <td><?php echo e($podcast->video_url); ?></td>
                                    <td><?php echo e($podcast->published_at); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('podcasts.show', $podcast->id)); ?>" class="btn btn-info btn-sm">View</a>
                                        <a href="<?php echo e(route('podcasts.edit', $podcast->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                        <button class="btn btn-danger btn-sm" onclick="deletePodcast(<?php echo e($podcast->id); ?>)">Delete</button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($podcasts->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function deletePodcast(id) {
    if (!confirm('Are you sure you want to delete this podcast?')) return;
    fetch('/podcasts/' + id, {
        method: 'DELETE',
        headers: {
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert(data.message || 'Failed to delete podcast.');
        }
    });
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\najam\resources\views/podcasts/index.blade.php ENDPATH**/ ?>
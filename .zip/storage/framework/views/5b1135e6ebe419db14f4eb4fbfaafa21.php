

<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <strong>Speaking Requests</strong>
                    </div>
                    <div class="table-stats order-table ov-h">
                        <table class="table ">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Organization</th>
                                    <th>Event Type</th>
                                    <th>Event Date</th>
                                    <th>Expected Attendees</th>
                                    <th>Event Location</th>
                                    <th>Budget Range</th>
                                    <th>Additional Details</th>
                                    <th>Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $speakingRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($request->id); ?></td>
                                        <td><?php echo e($request->first_name); ?></td>
                                        <td><?php echo e($request->last_name); ?></td>
                                        <td><?php echo e($request->email); ?></td>
                                        <td><?php echo e($request->phone); ?></td>
                                        <td><?php echo e($request->organization); ?></td>
                                        <td><?php echo e($request->event_type); ?></td>
                                        <td><?php echo e($request->event_date); ?></td>
                                        <td><?php echo e($request->expected_attendees); ?></td>
                                        <td><?php echo e($request->event_location); ?></td>
                                        <td><?php echo e($request->budget_range); ?></td>
                                        <td><?php echo e($request->additional_details); ?></td>
                                        <td><?php echo e($request->created_at); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer d-flex justify-content-end align-items-center">
                        <?php echo e($speakingRequests->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\najam\resources\views/speaking/request.blade.php ENDPATH**/ ?>
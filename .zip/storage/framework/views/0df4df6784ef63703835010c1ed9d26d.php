<nav class="navbar navbar-expand-sm navbar-default">
    <div id="main-menu" class="main-menu collapse navbar-collapse">
        <ul class="nav navbar-nav">
            <!-- Dashboard -->
            <li>
                <a href="<?php echo e(route('home')); ?>"><i class="menu-icon fa fa-laptop"></i>Dashboard</a>
            </li>

            <!-- Coaching Services -->
            

            <!-- Books -->
            

            <!-- Success Stories -->
            

            <!-- Testimonials -->
            <li class="menu-title">Testimonials</li>
            <li>
                <a href="<?php echo e(route('testimonials.index')); ?>"><i class="menu-icon fa fa-comments"></i>All Testimonials</a>
            </li>
            <li>
                <a href="<?php echo e(route('testimonials.create')); ?>"><i class="menu-icon fa fa-plus"></i>Add Testimonial</a>
            </li>

            <!-- Blogs -->
            <li class="menu-title">Blogs</li>
            <li>
                <a href="<?php echo e(route('blog.index')); ?>"><i class="menu-icon fa fa-envelope"></i>View</a>
            </li>
            <li>
                <a href="<?php echo e(route('blog.create')); ?>"><i class="menu-icon fa fa-envelope"></i>Create</a>
            </li>

             <!-- PodCast -->
            <li class="menu-title">PodCast</li>
            <li>
                <a href="<?php echo e(route('podcasts.index')); ?>"><i class="menu-icon fa fa-microphone"></i>All Podcasts</a>
            </li>
            <li>
                <a href="<?php echo e(route('podcasts.create')); ?>"><i class="menu-icon fa fa-plus"></i>Add Podcast</a>
            </li>

            <!-- Contact Messages -->
            <li class="menu-title">Contact Messages</li>
            <li>
                <a href="<?php echo e(route('contact.index')); ?>"><i class="menu-icon fa fa-envelope"></i>Contact Messages</a>
            </li>


            <!-- Contact Messages -->
            <li class="menu-title">Speaking Requests</li>
            <li>
                <a href="<?php echo e(route('speaking.show')); ?>"><i class="menu-icon fa fa-envelope"></i>Requests</a>
            </li>

            <!-- Resources -->
            

            <!-- Contact & Forms -->
            

            <!-- Site Settings -->
            

            <!-- User Management -->
            

            <!-- Profile & Security -->
            
        </ul>
    </div><!-- /.navbar-collapse -->
</nav><?php /**PATH C:\laragon\www\najam\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>
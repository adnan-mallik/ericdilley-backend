<footer class="bdT ta-c p-30 lh-0 fsz-sm c-grey-600">
    <span>Copyright © 2025 Designed by <a href="https://softpulse.org" target="_blank" rel="nofollow noopener noreferrer" title="Colorlib">Soft Pulse</a>. All rights reserved.</span>
</footer>